#!/usr/bin/env python
from __future__ import print_function, division
import pycreate2
import time
import sys
import cv2
import ar_markers
from ar_markers import detect_markers
from opencvutils import Camera

lineSensitivity = 1500
objectSensitivity = 500
global task
task = 3
global obst 
obst = False

def getPosition(bot):
	# Commented out for time trials
	# stop = True
	# while(stop):
	# 	sen = bot.get_sensors()
	# 	for sensor in sen.light_bumper:
	# 		if(sensor==True):
	# 			stop = True
	# 			bot.drive_stop()
	# 			bot.digit_led_ascii('obst')
	# 			break
	# 		else:
	# 			bot.digit_led_ascii('    ')
	# 			stop = False
	sen = bot.get_sensors()
	c1 = not sen.cliff_left_signal//lineSensitivity
	c2 = not sen.cliff_front_left_signal//lineSensitivity
	c3 = not sen.cliff_front_right_signal//lineSensitivity
	c4 = not sen.cliff_right_signal//lineSensitivity
	
	if(c1):
		# Left
		return 1
	elif(c4):
		# Right
		return 2
	elif(c2):
		# Front Left
		return 3
	elif(c3):
		# Front Right
		return 4
	else:
		return 5

def getPosition2(bot):
	sen = bot.get_sensors()
	# Commented out for time trials
	# for sensor in sen.light_bumper:
	# 	if(sensor==True):
	# 		bot.digit_led_ascii('obst')
	# 		bot.drive_stop()
	# 		global obst 
	# 		obst = True
	# 		return 0
	# 	else:
	# 		bot.digit_led_ascii('    ')
	
	c1 = not sen.cliff_left_signal//lineSensitivity
	c2 = not sen.cliff_front_left_signal//lineSensitivity
	c3 = not sen.cliff_front_right_signal//lineSensitivity
	c4 = not sen.cliff_right_signal//lineSensitivity
	
	if(c1):
		# Left
		return 1
	elif(c4):
		# Right
		return 2
	elif(c2):
		# Front Left
		return 3
	elif(c3):
		# Front Right
		return 4
	else:
		return 5

def followLine(bot):
	bot.drive_distance(.1,500)
	GO = True
	while GO:
		if(task==3):
			pos = getPosition2(bot)
		else:
			pos = getPosition(bot)
		if(pos==1 or pos==2):
			# Intersection
			GO = False
		elif(pos==3):
			# Veer Left
			bot.drive_direct(500,430) # Range of -500 to 500 (rVel,lVel)
		elif(pos==4):
			# Veer Right
			bot.drive_direct(430,500)
		elif(pos==5):
			# Drive Straight
			bot.drive_straight(500) # Range of -500 to 500
	return pos

def read_AR_code():
	cam = Camera(cam='pi')
	cam.init(win=(640,480))
	good, img = cam.read()
	if good:
			frame = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
			markers = detect_markers(frame)
			if(len(markers)>0):
				cam.close()
				return markers[0].id
			else:
				cam.close()
				return 0

def task2(bot):
	"""
	Follow lines, detect AR codes at intersections, navigate according to the code
	0: No AR code found
	1111: go straight
	2222: go right
	3333: go left
	4000: stop/complete/end of course
	"""
	instr = 1111
	while(instr != 4000):
		pos = followLine(bot)
		sen = bot.get_sensors()
		c1 = not sen.cliff_left_signal//lineSensitivity
		c4 = not sen.cliff_right_signal//lineSensitivity
		if(c1 and c4):
			instr = read_AR_code()
			if(instr==2222):
				bot.turn_angle(-90,200)
			elif(instr==3333):
				bot.turn_angle(90,200)
		else:
			if(c1):
				bot.turn_angle(90,200) # Turn Left
			elif(c4):
				bot.turn_angle(-90,200) # Turn Right
		
	bot.drive_stop()

def getPath(expand, goal, start, grid, wall=-1):
    """
    Given the expance (explored world), this returns the path from the goal
    to the starting point. This works backwards and takes the
    path with the lowest number of moves.
    """
    path = []
    x, y = goal
    val = expand[x][y]
    delta = [
        [-1, 0 ], # go up
        [ 0, -1], # go left
        [ 1, 0 ], # go down
        [ 0, 1 ]  # go right
    ]

    done = False
    max_x_grid = len(grid)
    max_y_grid = len(grid[0])
    
    path.append(goal)
    
    while not done:
        vals = []
        
        # lets find the move cost up/down/left/right
        for move in delta:
            x2, y2 = x + move[0], y + move[1]
            # make sure still on map
            if x2 >= 0 and x2 < max_x_grid and y2 >=0 and y2 < max_y_grid:
                if expand[x2][y2] > wall:  # don't travel through walls
                    val = expand[x2][y2]
                    vals.append((val, move))

        # find the lowest move cost
        lowest = 100000
        for v, m in vals:
            if v < lowest:
                move = m
                lowest = v

        # append that move to the path
        x, y = x + move[0], y + move[1]
        path.append([x, y])
        
        # are we there yet???
        if x == start[0] and y == start[1]:
            done = True
        
    return path

def a_star(grid,init,goal,cost,heuristic):
    # keep track of what is open to explore and what has been closed
    closed = [[0 for col in range(len(grid[0]))] for row in range(len(grid))]
    closed[init[0]][init[1]] = 1

    expand = [[-1 for col in range(len(grid[0]))] for row in range(len(grid))]
    action = [[-1 for col in range(len(grid[0]))] for row in range(len(grid))]
    
    
    delta = [[-1, 0], # go up
             [ 0,-1], # go left
             [ 1, 0], # go down
             [ 0, 1]] # go right

    x, y = init
    g = 0
    h = heuristic[x][y]
    f = g + h

    open = [[f, g, x, y]]  # add f

    found = False  # flag that is set when search is complete
    resign = False # flag set if we can't find expand
    count = 0
    
    while not found and not resign:
        if len(open) == 0:
            resign = True
            return "Fail"
        else:
            open.sort()
            open.reverse()
            next = open.pop()
            x = next[2]
            y = next[3]
            g = next[1]
            expand[x][y] = count
            count += 1
            
            if x == goal[0] and y == goal[1]:
                found = True
            else:
                # expand winning element and add to new open list
                for i in range(len(delta)):
                    x2 = x + delta[i][0]
                    y2 = y + delta[i][1]
                    # make sure still on map
                    if x2 >= 0 and x2 < len(grid) and y2 >=0 and y2 < len(grid[0]):
                        # make sure unoccuppied
                        if closed[x2][y2] == 0 and grid[x2][y2] == 0:
                            g2 = g + cost
                            h2 = heuristic[x2][y2]
                            f2 = g2 + h2
                            open.append([f2, g2, x2, y2])
                            closed[x2][y2] = 1

    return expand

def calcHeuristic(grid, goal):
    """
    Basically calculates a gradient decent from a given
    goal point. A heuristic can be more complex
    """
    w = len(grid[0])  # width
    h = len(grid)     # height
    hr = [[(abs(goal[1]-y)+abs(goal[0]-x)) for y in range(w)] for x in range(h)]
    return hr

def heading(bot, curDir, newDir):
	if(curDir=="down" and newDir=="up"):
		bot.turn_angle(180,300)
	elif(curDir=="down" and newDir=="left"):
		bot.turn_angle(-60,500)
	elif(curDir=="down" and newDir=="right"):
		bot.turn_angle(90,300)
	elif(curDir=="left" and newDir=="up"):
		bot.turn_angle(-70,500)
	elif(curDir=="left" and newDir=="down"):
		bot.turn_angle(90,300)
	elif(curDir=="left" and newDir=="right"):
		bot.turn_angle(180,300)
	elif(curDir=="right" and newDir=="up"):
		bot.turn_angle(70,300)
	elif(curDir=="right" and newDir=="down"):
		bot.turn_angle(-90,300)
	elif(curDir=="right" and newDir=="left"):
		bot.turn_angle(180,300)
	elif(curDir=="up" and newDir=="left"):
		bot.turn_angle(90,300)
	elif(curDir=="up" and newDir=="right"):
		bot.turn_angle(-90,300)
	elif(curDir=="up" and newDir=="down"):
		bot.turn_angle(180,300)

def task3(bot):
	curDir = "down"
	grid = [[0, 1, 0, 0, 0, 0, 0],
        	[0, 1, 0, 1, 0, 1, 0],
        	[0, 0, 0, 0, 0, 0, 0],
        	[0, 1, 0, 1, 1, 1, 1],
        	[0, 0, 0, 0, 0, 1, 1]]
	goal = [0,0]
	init = [0,6]
	cost = 1
	heuristic = calcHeuristic(grid, goal)
	ans = a_star(grid,init,goal,cost,heuristic)
	path = getPath(ans, goal, init, grid)
	path.reverse()
	while path[0]!=goal:
		y1,x1 = path[0]
		del path[0]
		y2,x2 = path[0]
		if(x2>x1):
			newDir = "right"
			heading(bot, curDir, newDir)
			curDir = "right"
		elif(x2<x1):
			newDir = "left"
			heading(bot, curDir, newDir)
			curDir = "left"
		elif(y2>y1):
			newDir = "down"
			heading(bot, curDir, newDir)
			curDir = "down"
		elif(y2<y1):
			newDir = "up"
			heading(bot, curDir, newDir)
			curDir = "up"
		followLine(bot)
		if(obst):
			grid[y2][x2] = 1
			init = [y1,x1]
			bot.turn_angle(200, 200)
			followLine(bot)
			bot.turn_angle(200,200)
			heuristic = calcHeuristic(grid, goal)
			ans = a_star(grid,init,goal,cost,heuristic)
			path = getPath(ans, goal, init, grid)
			path.reverse()
			global obst
			obst = False
		else:
			del path[0]
	bot.drive_stop()

if __name__=="__main__":
	bot = pycreate2.Create2('/dev/ttyUSB0')
	bot.start()
	bot.full()
	task3(bot)
	bot.close()